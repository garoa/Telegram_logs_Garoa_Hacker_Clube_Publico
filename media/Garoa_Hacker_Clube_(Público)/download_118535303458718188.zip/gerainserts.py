#!/usr/bin/python3
import re
import random
import codecs

def upsert(table, **kwargs):
  """ update/insert rows into objects table (update if the row already exists)
      given the key-value pairs in kwargs """
  keys = ["%s" % k for k in kwargs]
  values = ["'%s'" % v for v in kwargs.values()]
  sql = list()
  sql.append("INSERT INTO %s (" % table)
  sql.append(", ".join(keys))
  sql.append(") VALUES (")
  sql.append(", ".join(values))
  sql.append(") ON DUPLICATE KEY UPDATE ")
  sql.append(", ".join("%s = '%s'" % (k, v) for k, v in kwargs.iteritems()))
  sql.append(";")
  return "".join(sql)

def geraBanda():
  return " ".join([random.choice(dic["sub"].split("\n")),random.choice(dic["adj"].split("\n"))])

def geraNome():
  return " ".join([random.choice(dic["nome"].split("\n")),random.choice(dic["snome  "].split("\n"))])

dic = {}
dic["adj"] = re.sub('["]', '', codecs.open('dict/adj.txt', 'r', encoding='utf-8').read())
dic["sub"] = re.sub('["]', '', codecs.open('dict/sub.txt', 'r', encoding='utf-8').read())
dic["nome"] = re.sub('["]', '', codecs.open('dict/nomes.txt', 'r', encoding='utf-8').read())
dic["snome"] = re.sub('["]', '', codecs.open('dict/sobrenomes.txt', 'r', encoding='utf-8').read())
